import streamlit as st

st.header('Jogando uma moeda')

st.write('Ainda não é um aplicativo funcional. Em construção.')
